import Stripe from 'npm:stripe@^22'
import { corsHeaders, json, env, adminClient, currentUser } from '../_shared/common.ts'

const stripe = new Stripe(env('STRIPE_SECRET_KEY'))

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  try {
    const user = await currentUser(req)
    const body = await req.json().catch(() => ({}))
    const interval = String(body?.interval || 'month')
    if (!['month', 'year'].includes(interval)) return json({ error: 'Invalid interval' }, 400)

    const price = interval === 'year'
      ? env('STRIPE_PRICE_PLUS_YEAR')
      : env('STRIPE_PRICE_PLUS_MONTH')

    const admin = adminClient()
    const { data: profile, error } = await admin
      .from('climaflora_profiles')
      .select('first_name,last_name,stripe_customer_id')
      .eq('id', user.id)
      .single()
    if (error) throw error

    let customerId = profile?.stripe_customer_id || ''
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email || undefined,
        name: [profile?.first_name, profile?.last_name].filter(Boolean).join(' ') || undefined,
        metadata: { climaflora_user_id: user.id },
      })
      customerId = customer.id
      const { error: updateError } = await admin
        .from('climaflora_profiles')
        .update({ stripe_customer_id: customerId, updated_at: new Date().toISOString() })
        .eq('id', user.id)
      if (updateError) throw updateError
    }

    const site = env('CLIMAFLORA_SITE_URL').replace(/\/$/, '')
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      client_reference_id: user.id,
      line_items: [{ price, quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${site}/?billing=success`,
      cancel_url: `${site}/?billing=cancel`,
      subscription_data: {
        metadata: { climaflora_user_id: user.id },
      },
      metadata: {
        climaflora_user_id: user.id,
        climaflora_plan: 'PLUS',
        climaflora_interval: interval,
      },
    })

    return json({ url: session.url })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Checkout error'
    return json({ error: message }, /Unauthorized/.test(message) ? 401 : 500)
  }
})
