import { createClient } from 'npm:@supabase/supabase-js@2'

export const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://shugoan.com',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

export function env(name: string): string {
  const value = Deno.env.get(name)?.trim()
  if (!value) throw new Error(`Missing secret ${name}`)
  return value
}

export function adminClient() {
  return createClient(env('SUPABASE_URL'), env('SUPABASE_SECRET_KEY'), {
    auth: { persistSession: false, autoRefreshToken: false },
  })
}

export async function currentUser(req: Request) {
  const authorization = req.headers.get('Authorization') || ''
  if (!authorization.startsWith('Bearer ')) throw new Error('Unauthorized')
  const token = authorization.slice('Bearer '.length)
  const admin = adminClient()
  const { data, error } = await admin.auth.getUser(token)
  if (error || !data.user) throw new Error('Unauthorized')
  return data.user
}

export async function requireAdmin(req: Request) {
  const user = await currentUser(req)
  const admin = adminClient()
  const { data, error } = await admin
    .from('climaflora_profiles')
    .select('role')
    .eq('id', user.id)
    .single()
  if (error || data?.role !== 'ADMIN') throw new Error('Forbidden')
  return { user, admin }
}
