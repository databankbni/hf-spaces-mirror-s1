import Stripe from 'npm:stripe@^22'
import { corsHeaders, json, env, adminClient, currentUser } from '../_shared/common.ts'

const stripe = new Stripe(env('STRIPE_SECRET_KEY'))

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  try {
    const user = await currentUser(req)
    const admin = adminClient()
    const { data: profile, error } = await admin
      .from('climaflora_profiles')
      .select('stripe_customer_id')
      .eq('id', user.id)
      .single()
    if (error) throw error
    if (!profile?.stripe_customer_id) return json({ error: 'No Stripe customer' }, 400)

    const site = env('CLIMAFLORA_SITE_URL').replace(/\/$/, '')
    const session = await stripe.billingPortal.sessions.create({
      customer: profile.stripe_customer_id,
      return_url: `${site}/`,
    })
    return json({ url: session.url })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Portal error'
    return json({ error: message }, /Unauthorized/.test(message) ? 401 : 500)
  }
})
