import Stripe from 'npm:stripe@^22'
import { json, env, adminClient } from '../_shared/common.ts'

const stripe = new Stripe(env('STRIPE_SECRET_KEY'))
const cryptoProvider = Stripe.createSubtleCryptoProvider()

function planFromPrice(priceId: string | null) {
  if (!priceId) return 'FREE'
  const plus = [Deno.env.get('STRIPE_PRICE_PLUS_MONTH'), Deno.env.get('STRIPE_PRICE_PLUS_YEAR')]
    .filter(Boolean)
  const pro = [Deno.env.get('STRIPE_PRICE_PRO_MONTH'), Deno.env.get('STRIPE_PRICE_PRO_YEAR')]
    .filter(Boolean)
  if (pro.includes(priceId)) return 'PRO'
  if (plus.includes(priceId)) return 'PLUS'
  return 'FREE'
}

function accessPlan(status: string, priceId: string | null) {
  return ['active', 'trialing'].includes(status) ? planFromPrice(priceId) : 'FREE'
}

async function syncSubscription(subscription: Stripe.Subscription) {
  const admin = adminClient()
  const userId = subscription.metadata?.climaflora_user_id || ''
  const customerId = typeof subscription.customer === 'string' ? subscription.customer : subscription.customer.id
  const item = subscription.items.data[0]
  const priceId = item?.price?.id || null
  const interval = item?.price?.recurring?.interval || null
  const plan = accessPlan(subscription.status, priceId)

  let resolvedUserId = userId
  if (!resolvedUserId) {
    const { data } = await admin
      .from('climaflora_profiles')
      .select('id')
      .eq('stripe_customer_id', customerId)
      .maybeSingle()
    resolvedUserId = data?.id || ''
  }
  if (!resolvedUserId) throw new Error(`No ClimaFlora user for Stripe customer ${customerId}`)

  const { error } = await admin
    .from('climaflora_profiles')
    .update({
      plan,
      stripe_customer_id: customerId,
      stripe_subscription_id: subscription.id,
      subscription_price_id: priceId,
      billing_status: subscription.status,
      billing_interval: interval,
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      cancel_at_period_end: Boolean(subscription.cancel_at_period_end),
      updated_at: new Date().toISOString(),
    })
    .eq('id', resolvedUserId)
  if (error) throw error
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  const signature = req.headers.get('stripe-signature') || ''
  const body = await req.text()

  let event: Stripe.Event
  try {
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature,
      env('STRIPE_WEBHOOK_SECRET'),
      undefined,
      cryptoProvider,
    )
  } catch (error) {
    return json({ error: 'Invalid Stripe signature' }, 400)
  }

  try {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        await syncSubscription(event.data.object as Stripe.Subscription)
        break
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        if (typeof session.subscription === 'string') {
          const subscription = await stripe.subscriptions.retrieve(session.subscription)
          await syncSubscription(subscription)
        }
        break
      }
      default:
        break
    }
    return json({ received: true })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Webhook processing failed'
    return json({ error: message }, 500)
  }
})
