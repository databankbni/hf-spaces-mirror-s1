import { corsHeaders, json, requireAdmin } from '../_shared/common.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  try {
    const { user: caller, admin } = await requireAdmin(req)
    const body = await req.json().catch(() => ({}))
    const userId = String(body?.user_id || '')
    const plan = String(body?.plan || '').toUpperCase()
    if (!userId || !['FREE','PLUS','PRO'].includes(plan)) return json({ error: 'Invalid request' }, 400)

    // Do not let an admin accidentally downgrade their own admin access;
    // plan and role are separate, so only the plan changes here.
    const { error } = await admin
      .from('climaflora_profiles')
      .update({ plan, updated_at: new Date().toISOString() })
      .eq('id', userId)
    if (error) throw error

    return json({ ok: true, changed_by: caller.id, user_id: userId, plan })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Admin update failed'
    return json({ error: message }, message === 'Unauthorized' ? 401 : message === 'Forbidden' ? 403 : 500)
  }
})
