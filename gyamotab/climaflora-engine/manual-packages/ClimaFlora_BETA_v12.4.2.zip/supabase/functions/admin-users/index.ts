import { corsHeaders, json, requireAdmin } from '../_shared/common.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  try {
    const { admin } = await requireAdmin(req)
    const [{ data: authPage, error: authError }, { data: profiles, error: profileError }] = await Promise.all([
      admin.auth.admin.listUsers({ page: 1, perPage: 1000 }),
      admin.from('climaflora_profiles')
        .select('id,role,plan,first_name,last_name,billing_status,billing_interval,current_period_end,created_at')
        .order('created_at', { ascending: false }),
    ])
    if (authError) throw authError
    if (profileError) throw profileError

    const byId = new Map((profiles || []).map((p: any) => [p.id, p]))
    const users = (authPage?.users || []).map((u: any) => ({
      id: u.id,
      email: u.email,
      ...byId.get(u.id),
      created_at: byId.get(u.id)?.created_at || u.created_at,
    }))
    return json({ users })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Admin error'
    return json({ error: message }, message === 'Unauthorized' ? 401 : message === 'Forbidden' ? 403 : 500)
  }
})
