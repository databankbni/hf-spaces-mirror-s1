-- ClimaFlora Auth v1.3 — Admin via PostgreSQL RPC
-- Safe after AUTH_SUPABASE_V1_2_BILLING_ADMIN.sql.

begin;

create or replace function public.climaflora_admin_users()
returns table (
  id uuid,
  email text,
  first_name text,
  last_name text,
  role text,
  plan text,
  billing_status text,
  billing_interval text,
  current_period_end timestamptz,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.climaflora_is_admin() then
    raise exception 'Forbidden';
  end if;

  return query
  select
    p.id,
    u.email::text,
    p.first_name,
    p.last_name,
    p.role,
    p.plan,
    p.billing_status,
    p.billing_interval,
    p.current_period_end,
    p.created_at
  from public.climaflora_profiles p
  join auth.users u on u.id = p.id
  order by p.created_at desc;
end;
$$;

revoke all on function public.climaflora_admin_users() from public;
grant execute on function public.climaflora_admin_users() to authenticated;

create or replace function public.climaflora_admin_set_plan(
  p_user_id uuid,
  p_plan text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_plan text := upper(trim(coalesce(p_plan, '')));
begin
  if not public.climaflora_is_admin() then
    raise exception 'Forbidden';
  end if;

  if v_plan not in ('FREE', 'PLUS', 'PRO') then
    raise exception 'Invalid plan';
  end if;

  update public.climaflora_profiles
  set plan = v_plan,
      updated_at = now()
  where id = p_user_id;

  if not found then
    raise exception 'User not found';
  end if;
end;
$$;

revoke all on function public.climaflora_admin_set_plan(uuid, text) from public;
grant execute on function public.climaflora_admin_set_plan(uuid, text) to authenticated;

commit;
