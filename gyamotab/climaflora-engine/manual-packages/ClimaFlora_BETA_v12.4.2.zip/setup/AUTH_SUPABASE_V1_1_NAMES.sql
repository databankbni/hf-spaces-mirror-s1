-- ClimaFlora Auth v1.1 — add first name / last name
-- Safe to run after AUTH_SUPABASE_V1.sql.

begin;

alter table public.climaflora_profiles add column if not exists first_name text;
alter table public.climaflora_profiles add column if not exists last_name text;

create or replace function public.climaflora_create_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.climaflora_profiles (id, first_name, last_name, display_name, plan)
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'first_name', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'last_name', '')), ''),
    nullif(trim(coalesce(
      new.raw_user_meta_data ->> 'display_name',
      concat_ws(' ',
        nullif(trim(coalesce(new.raw_user_meta_data ->> 'first_name', '')), ''),
        nullif(trim(coalesce(new.raw_user_meta_data ->> 'last_name', '')), '')
      )
    )), ''),
    'FREE'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

revoke all on function public.climaflora_create_profile() from public;

-- Populate name fields for any users that may already exist.
update public.climaflora_profiles p
set
  first_name = coalesce(p.first_name, nullif(trim(coalesce(u.raw_user_meta_data ->> 'first_name', '')), '')),
  last_name = coalesce(p.last_name, nullif(trim(coalesce(u.raw_user_meta_data ->> 'last_name', '')), '')),
  display_name = coalesce(
    p.display_name,
    nullif(trim(coalesce(
      u.raw_user_meta_data ->> 'display_name',
      concat_ws(' ',
        nullif(trim(coalesce(u.raw_user_meta_data ->> 'first_name', '')), ''),
        nullif(trim(coalesce(u.raw_user_meta_data ->> 'last_name', '')), '')
      )
    )), '')
  ),
  updated_at = now()
from auth.users u
where p.id = u.id;

commit;
