-- ClimaFlora Auth / ClimaFlora+ v1
-- Run once in the Supabase SQL editor.
-- The service_role key must NEVER be exposed in the frontend.

begin;

create table if not exists public.climaflora_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text,
  last_name text,
  display_name text,
  plan text not null default 'FREE' check (plan in ('FREE','PLUS','PRO')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.climaflora_profiles add column if not exists first_name text;
alter table public.climaflora_profiles add column if not exists last_name text;

alter table public.climaflora_profiles enable row level security;
revoke all on public.climaflora_profiles from anon;
revoke insert, update, delete on public.climaflora_profiles from authenticated;
grant select on public.climaflora_profiles to authenticated;

drop policy if exists "climaflora profile self read" on public.climaflora_profiles;
create policy "climaflora profile self read"
on public.climaflora_profiles
for select
to authenticated
using (id = auth.uid());

create or replace function public.climaflora_create_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.climaflora_profiles (id, first_name, last_name, display_name, plan)
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'first_name', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'last_name', '')), ''),
    nullif(trim(coalesce(
      new.raw_user_meta_data ->> 'display_name',
      concat_ws(' ',
        nullif(trim(coalesce(new.raw_user_meta_data ->> 'first_name', '')), ''),
        nullif(trim(coalesce(new.raw_user_meta_data ->> 'last_name', '')), '')
      )
    )), ''),
    'FREE'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

revoke all on function public.climaflora_create_profile() from public;

drop trigger if exists climaflora_auth_user_created on auth.users;
create trigger climaflora_auth_user_created
after insert on auth.users
for each row execute function public.climaflora_create_profile();

-- Backfill profiles if auth users already exist.
insert into public.climaflora_profiles (id, first_name, last_name, display_name, plan)
select
  id,
  nullif(trim(coalesce(raw_user_meta_data ->> 'first_name', '')), ''),
  nullif(trim(coalesce(raw_user_meta_data ->> 'last_name', '')), ''),
  nullif(trim(coalesce(
    raw_user_meta_data ->> 'display_name',
    concat_ws(' ',
      nullif(trim(coalesce(raw_user_meta_data ->> 'first_name', '')), ''),
      nullif(trim(coalesce(raw_user_meta_data ->> 'last_name', '')), '')
    )
  )), ''),
  'FREE'
from auth.users
on conflict (id) do nothing;

create or replace function public.climaflora_has_plus()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.climaflora_profiles p
    where p.id = auth.uid()
      and p.plan in ('PLUS','PRO')
  );
$$;

revoke all on function public.climaflora_has_plus() from public;
grant execute on function public.climaflora_has_plus() to authenticated;

create table if not exists public.climaflora_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  latitude double precision check (latitude between -90 and 90),
  longitude double precision check (longitude between -180 and 180),
  horizon text,
  scenario text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists climaflora_projects_user_idx on public.climaflora_projects(user_id, updated_at desc);
alter table public.climaflora_projects enable row level security;
grant select, insert, update, delete on public.climaflora_projects to authenticated;
revoke all on public.climaflora_projects from anon;

drop policy if exists "climaflora plus projects select" on public.climaflora_projects;
create policy "climaflora plus projects select" on public.climaflora_projects
for select to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus projects insert" on public.climaflora_projects;
create policy "climaflora plus projects insert" on public.climaflora_projects
for insert to authenticated with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus projects update" on public.climaflora_projects;
create policy "climaflora plus projects update" on public.climaflora_projects
for update to authenticated using (user_id = auth.uid() and public.climaflora_has_plus())
with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus projects delete" on public.climaflora_projects;
create policy "climaflora plus projects delete" on public.climaflora_projects
for delete to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());

create table if not exists public.climaflora_palette_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id uuid references public.climaflora_projects(id) on delete cascade,
  taxon_id text not null,
  scientific_name text,
  notes text,
  created_at timestamptz not null default now(),
  unique (user_id, project_id, taxon_id)
);

create index if not exists climaflora_palette_user_idx on public.climaflora_palette_items(user_id, created_at desc);
alter table public.climaflora_palette_items enable row level security;
grant select, insert, update, delete on public.climaflora_palette_items to authenticated;
revoke all on public.climaflora_palette_items from anon;

drop policy if exists "climaflora plus palette select" on public.climaflora_palette_items;
create policy "climaflora plus palette select" on public.climaflora_palette_items
for select to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus palette insert" on public.climaflora_palette_items;
create policy "climaflora plus palette insert" on public.climaflora_palette_items
for insert to authenticated with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus palette update" on public.climaflora_palette_items;
create policy "climaflora plus palette update" on public.climaflora_palette_items
for update to authenticated using (user_id = auth.uid() and public.climaflora_has_plus())
with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus palette delete" on public.climaflora_palette_items;
create policy "climaflora plus palette delete" on public.climaflora_palette_items
for delete to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());

create table if not exists public.climaflora_comparisons (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Comparaison',
  taxon_ids text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists climaflora_comparisons_user_idx on public.climaflora_comparisons(user_id, updated_at desc);
alter table public.climaflora_comparisons enable row level security;
grant select, insert, update, delete on public.climaflora_comparisons to authenticated;
revoke all on public.climaflora_comparisons from anon;

drop policy if exists "climaflora plus comparisons select" on public.climaflora_comparisons;
create policy "climaflora plus comparisons select" on public.climaflora_comparisons
for select to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus comparisons insert" on public.climaflora_comparisons;
create policy "climaflora plus comparisons insert" on public.climaflora_comparisons
for insert to authenticated with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus comparisons update" on public.climaflora_comparisons;
create policy "climaflora plus comparisons update" on public.climaflora_comparisons
for update to authenticated using (user_id = auth.uid() and public.climaflora_has_plus())
with check (user_id = auth.uid() and public.climaflora_has_plus());
drop policy if exists "climaflora plus comparisons delete" on public.climaflora_comparisons;
create policy "climaflora plus comparisons delete" on public.climaflora_comparisons
for delete to authenticated using (user_id = auth.uid() and public.climaflora_has_plus());

commit;
