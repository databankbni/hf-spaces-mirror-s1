# ClimaFlora Billing/Admin v1

## Architecture

- Stripe Checkout: souscription.
- Stripe Customer Portal: modification / résiliation par le client.
- Supabase Edge Functions: création des sessions Stripe et traitement du webhook.
- Supabase PostgreSQL: source de vérité des droits ClimaFlora.
- `plan`: FREE / PLUS / PRO.
- `role`: USER / ADMIN. Le rôle admin est totalement distinct du plan commercial.
- Le frontend ne contient aucune clé Stripe secrète.

## 1. Migration Supabase

Dans SQL Editor, exécuter :

`setup/AUTH_SUPABASE_V1_2_BILLING_ADMIN.sql`

Une fois votre compte ClimaFlora créé, vous pouvez le passer ADMIN avec la requête commentée à la fin du fichier.

## 2. Stripe

Dans Stripe Dashboard :

1. Créer le produit `ClimaFlora+`.
2. Ajouter un prix récurrent mensuel.
3. Ajouter un prix récurrent annuel.
4. Noter les identifiants `price_...`.
5. Activer/configurer le Customer Portal.

Aucun montant n'est codé dans le frontend.

## 3. Secrets Supabase Edge Functions

Dans Supabase > Edge Functions > Secrets, créer :

- `SUPABASE_SECRET_KEY` = clé secrète Supabase `sb_secret_...` (JAMAIS dans le frontend)
- `STRIPE_SECRET_KEY` = clé Stripe `sk_live_...` ou `sk_test_...`
- `STRIPE_PRICE_PLUS_MONTH` = `price_...`
- `STRIPE_PRICE_PLUS_YEAR` = `price_...`
- `CLIMAFLORA_SITE_URL` = `https://shugoan.com/climaflora`
- `STRIPE_WEBHOOK_SECRET` = à renseigner après création du webhook Stripe

Optionnel plus tard :
- `STRIPE_PRICE_PRO_MONTH`
- `STRIPE_PRICE_PRO_YEAR`

Ne collez pas ces secrets dans ChatGPT, GitHub ou le frontend.

## 4. Déployer les Edge Functions

Les sources sont dans `supabase/functions/`.

Fonctions :
- `create-checkout-session`
- `create-portal-session`
- `stripe-webhook`
- `admin-users`
- `admin-set-plan`

Le webhook Stripe doit être public (`verify_jwt=false`) car Stripe ne possède pas de JWT Supabase. Sa signature Stripe est vérifiée par la fonction.

## 5. Webhook Stripe

Créer dans Stripe un webhook pointant vers :

`https://haclvcuxadvuigtefeqz.supabase.co/functions/v1/stripe-webhook`

Événements :
- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`

Copier le Signing secret `whsec_...` dans le secret Supabase `STRIPE_WEBHOOK_SECRET`.

## 6. Logique des droits

- abonnement Stripe `active` / `trialing` + price PLUS -> `plan=PLUS`
- abonnement Stripe supprimé/inactif -> `plan=FREE`
- le rôle `ADMIN` n'est jamais modifié par Stripe.
- un ADMIN peut attribuer manuellement FREE / PLUS / PRO depuis le back-office.

## 7. Admin

Le bouton Administration n'apparaît que si `climaflora_profiles.role = 'ADMIN'`.

Le frontend ne peut pas s'auto-promouvoir :
- le rôle est lu depuis PostgreSQL,
- l'action admin est revalidée côté Edge Function,
- la fonction utilise ensuite la clé serveur pour effectuer l'opération.

## 8. Test recommandé

Commencer en Stripe Test Mode :
1. créer les prix TEST,
2. mettre `sk_test_...`,
3. créer le webhook TEST,
4. tester souscription,
5. vérifier `plan=PLUS`,
6. tester Customer Portal et résiliation,
7. vérifier retour à FREE,
8. seulement ensuite passer aux clés/prix LIVE.
