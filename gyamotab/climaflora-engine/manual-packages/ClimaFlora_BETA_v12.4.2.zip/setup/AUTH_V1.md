# ClimaFlora Auth v1 — architecture

## Décision

ClimaFlora n'utilise pas WordPress comme magasin d'identités. L'authentification est portée par Supabase Auth et les données transactionnelles par PostgreSQL/Supabase. WordPress peut rester le CMS de shugoan.com sans devenir une dépendance de ClimaFlora.

## Plans

- `FREE` : moteur scientifique public et compte personnel.
- `PLUS` : `Mes projets`, `Ma palette`, `Comparateur`.
- `PRO` : inclut PLUS et recevra ensuite les fonctions professionnelles.

Le plan est stocké côté serveur dans `public.climaflora_profiles`. Le navigateur ne peut pas modifier ce champ. Un futur webhook de facturation utilisera une clé serveur `service_role` pour passer le compte de FREE à PLUS/PRO ou inversement.

## Sécurité

- Le mot de passe n'est jamais stocké ni traité par le code ClimaFlora : Supabase Auth s'en charge.
- Le frontend ne reçoit que la clé publique Supabase, prévue pour être exposée dans un navigateur.
- La clé `service_role` ne doit jamais être placée dans `auth-config.js` ni dans les fichiers OVH.
- Les tables ClimaFlora+ utilisent Row Level Security (RLS).
- Même si quelqu'un modifie le JavaScript pour enlever un cadenas, PostgreSQL refuse l'accès à un utilisateur FREE.
- Les données scientifiques et le scoring restent complètement indépendants de l'authentification.

## Activation

1. Créer un projet Supabase.
2. Exécuter `AUTH_SUPABASE_V1.sql` dans le SQL Editor.
3. Dans Authentication, configurer l'URL du site : `https://shugoan.com/climaflora/`.
4. Copier l'URL du projet et la clé publique/publishable Supabase.
5. Les renseigner dans `static/auth-config.js` : `supabaseUrl` et `publicKey`.
6. Déployer le frontend ClimaFlora.

## Test de ClimaFlora+

Un nouveau compte est toujours `FREE`. Pour tester PLUS avant la facturation, modifier le profil avec une requête exécutée dans le SQL Editor :

```sql
update public.climaflora_profiles
set plan = 'PLUS', updated_at = now()
where id = (select id from auth.users where email = 'adresse-de-test@example.com');
```

## Facturation future

Stripe (ou un autre prestataire) ne devra jamais être appelé depuis le moteur scientifique. Un webhook serveur mettra uniquement à jour `climaflora_profiles.plan` et, plus tard, les dates/états d'abonnement. Les RLS appliquent ensuite automatiquement les droits.
