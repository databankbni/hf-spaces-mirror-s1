-- ClimaFlora Auth v1.2 — self-service profile and account deletion
-- Safe to run after AUTH_SUPABASE_V1.sql + AUTH_SUPABASE_V1_1_NAMES.sql.

begin;

-- Update only the current user's safe profile fields.
-- Plan remains impossible to change through this function.
create or replace function public.climaflora_update_own_profile(
  p_first_name text,
  p_last_name text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_first text := nullif(trim(coalesce(p_first_name, '')), '');
  v_last text := nullif(trim(coalesce(p_last_name, '')), '');
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;
  if v_first is null or v_last is null then
    raise exception 'First name and last name are required';
  end if;
  if char_length(v_first) > 80 or char_length(v_last) > 80 then
    raise exception 'Name too long';
  end if;

  update public.climaflora_profiles
  set
    first_name = v_first,
    last_name = v_last,
    display_name = concat_ws(' ', v_first, v_last),
    updated_at = now()
  where id = v_uid;

  if not found then
    raise exception 'Profile not found';
  end if;
end;
$$;

revoke all on function public.climaflora_update_own_profile(text, text) from public;
grant execute on function public.climaflora_update_own_profile(text, text) to authenticated;

-- Delete exactly the currently authenticated user.
-- All ClimaFlora rows reference auth.users with ON DELETE CASCADE.
create or replace function public.climaflora_delete_own_account()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;

  delete from auth.users
  where id = v_uid;

  if not found then
    raise exception 'User not found';
  end if;
end;
$$;

revoke all on function public.climaflora_delete_own_account() from public;
grant execute on function public.climaflora_delete_own_account() to authenticated;

commit;
