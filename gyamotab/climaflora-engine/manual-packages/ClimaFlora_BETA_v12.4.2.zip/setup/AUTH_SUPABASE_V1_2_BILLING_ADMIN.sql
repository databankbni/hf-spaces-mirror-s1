-- ClimaFlora Auth v1.2 — Billing + Admin
-- Safe to run after AUTH_SUPABASE_V1.sql and v1.1 names migration.

begin;

alter table public.climaflora_profiles add column if not exists role text not null default 'USER';
alter table public.climaflora_profiles add column if not exists stripe_customer_id text;
alter table public.climaflora_profiles add column if not exists stripe_subscription_id text;
alter table public.climaflora_profiles add column if not exists subscription_price_id text;
alter table public.climaflora_profiles add column if not exists billing_status text;
alter table public.climaflora_profiles add column if not exists billing_interval text;
alter table public.climaflora_profiles add column if not exists current_period_end timestamptz;
alter table public.climaflora_profiles add column if not exists cancel_at_period_end boolean not null default false;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'climaflora_profiles_role_check'
  ) then
    alter table public.climaflora_profiles
      add constraint climaflora_profiles_role_check check (role in ('USER','ADMIN'));
  end if;
end $$;

create unique index if not exists climaflora_profiles_stripe_customer_uidx
  on public.climaflora_profiles(stripe_customer_id)
  where stripe_customer_id is not null;

create unique index if not exists climaflora_profiles_stripe_subscription_uidx
  on public.climaflora_profiles(stripe_subscription_id)
  where stripe_subscription_id is not null;

create or replace function public.climaflora_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.climaflora_profiles p
    where p.id = auth.uid()
      and p.role = 'ADMIN'
  );
$$;

revoke all on function public.climaflora_is_admin() from public;
grant execute on function public.climaflora_is_admin() to authenticated;

-- Admin can inspect user-facing data, but plan/role changes remain server-side only.
drop policy if exists "climaflora admin profile read" on public.climaflora_profiles;
create policy "climaflora admin profile read"
on public.climaflora_profiles
for select to authenticated
using (public.climaflora_is_admin());

drop policy if exists "climaflora admin projects read" on public.climaflora_projects;
create policy "climaflora admin projects read"
on public.climaflora_projects
for select to authenticated
using (public.climaflora_is_admin());

drop policy if exists "climaflora admin palette read" on public.climaflora_palette_items;
create policy "climaflora admin palette read"
on public.climaflora_palette_items
for select to authenticated
using (public.climaflora_is_admin());

drop policy if exists "climaflora admin comparisons read" on public.climaflora_comparisons;
create policy "climaflora admin comparisons read"
on public.climaflora_comparisons
for select to authenticated
using (public.climaflora_is_admin());

commit;

-- AFTER your own ClimaFlora account exists, grant yourself admin manually
-- from the Supabase SQL Editor by replacing the email:
--
-- update public.climaflora_profiles
-- set role = 'ADMIN', updated_at = now()
-- where id = (select id from auth.users where lower(email) = lower('VOTRE_EMAIL'));
--
-- Verify:
-- select u.email, p.role, p.plan
-- from auth.users u join public.climaflora_profiles p on p.id=u.id
-- where p.role='ADMIN';
