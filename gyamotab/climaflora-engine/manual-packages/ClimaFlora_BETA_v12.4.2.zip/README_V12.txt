ClimaFlora BETA v12.4.2
Build frontend-v12-4-2-20260824-1

Modifications de cette révision :
- « Nouvelle recherche » efface les résultats, la fiche ouverte, les filtres, le lieu, la période, le scénario, les valeurs de sol et la recherche par plante, puis revient à l’état initial ;
- suppression du téléchargement automatique de toutes les pages lorsqu’un filtre ramène le sous-ensemble sous 5 000 plantes ;
- une recherche ou un filtre charge désormais une seule page de 100 plantes ;
- cache navigateur des 60 dernières pages filtrées : revenir à une combinaison déjà consultée est instantané ;
- distinction visuelle entre l’analyse scientifique initiale, l’application d’un filtre et le changement de page ;
- les compteurs de filtres restent ceux calculés par le moteur sur toute la population évaluée.

Aucune modification distante GitHub/Hugging Face/OVH n’a été effectuée pour produire ce paquet.
