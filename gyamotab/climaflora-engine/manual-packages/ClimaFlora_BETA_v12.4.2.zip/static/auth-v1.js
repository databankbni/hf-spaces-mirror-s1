(() => {
  'use strict';

  const VERSION = '1.3.0';
  const STORAGE_KEY = 'climaflora-auth-v1-session';
  const cfg = window.CLIMAFLORA_AUTH_CONFIG || {};
  const state = {
    configured: Boolean(String(cfg.supabaseUrl || '').trim() && String(cfg.publicKey || '').trim()),
    session: null,
    profile: null,
    modal: null,
    refreshTimer: null,
    pendingFeature: null
  };

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));

  const baseUrl = () => String(cfg.supabaseUrl || '').replace(/\/$/, '');
  const publicKey = () => String(cfg.publicKey || '').trim();
  const currentPlan = () => String(state.profile?.plan || 'FREE').toUpperCase();
  const currentRole = () => String(state.profile?.role || 'USER').toUpperCase();
  const hasPlus = () => ['PLUS', 'PRO'].includes(currentPlan());
  const isAdmin = () => currentRole() === 'ADMIN';
  const currentUser = () => state.session?.user || null;

  function parseJsonSafe(text) {
    try { return JSON.parse(text); } catch { return null; }
  }

  function authHeaders(accessToken=null) {
    const headers = {
      'apikey': publicKey(),
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
    return headers;
  }

  async function api(path, options={}) {
    if (!state.configured) throw new Error('Connexion ClimaFlora non configurée.');
    const response = await fetch(`${baseUrl()}${path}`, {
      cache: 'no-store',
      ...options,
      headers: {...authHeaders(options.accessToken), ...(options.headers || {})}
    });
    const text = await response.text();
    const payload = text ? parseJsonSafe(text) : null;
    if (!response.ok) {
      const message = payload?.msg || payload?.message || payload?.error_description || payload?.error || `HTTP ${response.status}`;
      const error = new Error(String(message));
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  }

  function normalizeSession(payload) {
    if (!payload?.access_token || !payload?.user) return null;
    const expiresAt = Number(payload.expires_at || (Math.floor(Date.now()/1000) + Number(payload.expires_in || 3600)));
    return {
      access_token: payload.access_token,
      refresh_token: payload.refresh_token || '',
      expires_at: expiresAt,
      user: payload.user
    };
  }

  function saveSession(session) {
    state.session = session;
    if (session) localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    else localStorage.removeItem(STORAGE_KEY);
    scheduleRefresh();
  }

  function loadStoredSession() {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = parseJsonSafe(raw);
    return parsed?.access_token && parsed?.user ? parsed : null;
  }

  function scheduleRefresh() {
    clearTimeout(state.refreshTimer);
    if (!state.session?.refresh_token) return;
    const delay = Math.max(15_000, (Number(state.session.expires_at || 0) * 1000) - Date.now() - 90_000);
    state.refreshTimer = setTimeout(() => refreshSession().catch(logoutLocal), delay);
  }

  async function refreshSession() {
    if (!state.session?.refresh_token) throw new Error('Session expirée.');
    const payload = await api('/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      body: JSON.stringify({refresh_token: state.session.refresh_token})
    });
    const session = normalizeSession(payload);
    if (!session) throw new Error('Réponse de renouvellement invalide.');
    saveSession(session);
    await loadProfile();
    syncUi();
    return session;
  }

  async function verifySession() {
    if (!state.session?.access_token) return false;
    if (Number(state.session.expires_at || 0) * 1000 < Date.now() + 60_000 && state.session.refresh_token) {
      await refreshSession();
      return true;
    }
    try {
      const user = await api('/auth/v1/user', {method:'GET', accessToken: state.session.access_token});
      if (!user?.id) throw new Error('Utilisateur invalide.');
      state.session.user = user;
      saveSession(state.session);
      return true;
    } catch (error) {
      if (error.status === 401 || error.status === 403) logoutLocal();
      throw error;
    }
  }

  async function loadProfile() {
    const user = currentUser();
    if (!user?.id || !state.session?.access_token) {
      state.profile = null;
      return null;
    }
    const query = new URLSearchParams({
      id: `eq.${user.id}`,
      select: 'id,role,plan,first_name,last_name,display_name,billing_status,billing_interval,current_period_end,cancel_at_period_end,created_at'
    });
    try {
      const rows = await api(`/rest/v1/climaflora_profiles?${query}`, {
        method:'GET',
        accessToken: state.session.access_token
      });
      state.profile = Array.isArray(rows) && rows[0] ? rows[0] : {id:user.id, role:'USER', plan:'FREE', first_name:'', last_name:'', display_name:'', billing_status:null, billing_interval:null, current_period_end:null, cancel_at_period_end:false};
    } catch (error) {
      console.warn('ClimaFlora profile unavailable:', error);
      state.profile = {id:user.id, role:'USER', plan:'FREE', first_name:'', last_name:'', display_name:'', billing_status:null, billing_interval:null, current_period_end:null, cancel_at_period_end:false};
    }
    return state.profile;
  }

  function logoutLocal() {
    saveSession(null);
    state.profile = null;
    syncUi();
  }

  async function logout() {
    const token = state.session?.access_token;
    try {
      if (token && state.configured) await api('/auth/v1/logout', {method:'POST', accessToken:token, body:'{}'});
    } catch (error) {
      console.warn('ClimaFlora logout remote:', error);
    } finally {
      logoutLocal();
      closeModal();
      toast('Vous êtes déconnecté.');
    }
  }

  async function login(email, password) {
    const payload = await api('/auth/v1/token?grant_type=password', {
      method:'POST',
      body:JSON.stringify({email:String(email||'').trim(), password:String(password||'')})
    });
    const session = normalizeSession(payload);
    if (!session) throw new Error('Session de connexion invalide.');
    saveSession(session);
    await loadProfile();
    syncUi();
    return session;
  }

  async function register(firstName, lastName, email, password) {
    const first = String(firstName || '').trim();
    const last = String(lastName || '').trim();
    if (!first || !last) throw new Error('Prénom et nom sont obligatoires.');
    const redirectTo = String(cfg.redirectUrl || 'https://shugoan.com/climaflora/');
    const payload = await api(`/auth/v1/signup?redirect_to=${encodeURIComponent(redirectTo)}`, {
      method:'POST',
      body:JSON.stringify({
        email:String(email||'').trim(),
        password:String(password||''),
        data:{
          first_name:first,
          last_name:last,
          display_name:`${first} ${last}`.trim(),
          full_name:`${first} ${last}`.trim()
        }
      })
    });
    const session = normalizeSession(payload);
    if (session) {
      saveSession(session);
      await loadProfile();
      syncUi();
      return {session, confirmationRequired:false};
    }
    return {session:null, confirmationRequired:Boolean(payload?.user)};
  }

  async function sendRecovery(email) {
    const redirectTo = String(cfg.redirectUrl || 'https://shugoan.com/climaflora/');
    await api(`/auth/v1/recover?redirect_to=${encodeURIComponent(redirectTo)}`, {
      method:'POST',
      body:JSON.stringify({email:String(email||'').trim()})
    });
  }

  async function updateOwnProfile(firstName, lastName) {
    if (!state.session?.access_token) throw new Error('Connexion requise.');
    const first = String(firstName || '').trim();
    const last = String(lastName || '').trim();
    if (!first || !last) throw new Error('Prénom et nom sont obligatoires.');
    if (first.length > 80 || last.length > 80) throw new Error('Prénom ou nom trop long.');

    await api('/rest/v1/rpc/climaflora_update_own_profile', {
      method:'POST',
      accessToken:state.session.access_token,
      body:JSON.stringify({p_first_name:first, p_last_name:last})
    });
    await loadProfile();
    syncUi();
    return state.profile;
  }

  async function deleteOwnAccount() {
    if (!state.session?.access_token) throw new Error('Connexion requise.');
    await api('/rest/v1/rpc/climaflora_delete_own_account', {
      method:'POST',
      accessToken:state.session.access_token,
      body:'{}'
    });
    saveSession(null);
    state.profile = null;
    syncUi();
    closeModal();
    toast('Votre compte ClimaFlora a été supprimé.');
  }

  function userLabel() {
    const user = currentUser();
    if (!user) return 'Connexion';
    const first = state.profile?.first_name || user.user_metadata?.first_name || '';
    const name = state.profile?.display_name || user.user_metadata?.display_name || '';
    return first ? String(first).slice(0,20) : (name ? name.split(/\s+/)[0].slice(0,20) : String(user.email || 'Mon compte').split('@')[0].slice(0,20));
  }

  function syncUi() {
    const button = document.getElementById('auth-button');
    if (button) {
      button.disabled = false;
      button.textContent = currentUser() ? userLabel() : 'Connexion';
      button.classList.toggle('cf-auth-connected', Boolean(currentUser()));
      button.title = currentUser() ? `${currentUser().email || ''} · ${currentPlan()}` : 'Se connecter à ClimaFlora';
    }
    document.querySelectorAll('[data-plus-feature]').forEach(button => {
      button.dataset.authState = !currentUser() ? 'guest' : (hasPlus() ? 'allowed' : 'locked');
      const small = button.querySelector('small');
      if (small) small.textContent = hasPlus() ? currentPlan() : 'ClimaFlora+';
    });
    const plusCard = document.querySelector('.plus-card');
    if (plusCard) {
      const hidePlusPromo = Boolean(currentUser() && hasPlus());
      plusCard.hidden = hidePlusPromo;
      plusCard.setAttribute('aria-hidden', String(hidePlusPromo));
    }
    document.documentElement.dataset.climafloraPlan = currentPlan();
    document.documentElement.dataset.climafloraRole = currentRole();
    document.documentElement.dataset.climafloraAuthenticated = String(Boolean(currentUser()));
    window.dispatchEvent(new CustomEvent('climaflora:auth-changed', {
      detail:{authenticated:Boolean(currentUser()), user:currentUser(), profile:state.profile, plan:currentPlan(), role:currentRole()}
    }));
  }

  function injectStyles() {
    if (document.getElementById('cf-auth-styles')) return;
    const style = document.createElement('style');
    style.id = 'cf-auth-styles';
    style.textContent = `
      .cf-auth-overlay{position:fixed;inset:0;z-index:12000;background:rgba(14,27,20,.52);display:grid;place-items:center;padding:20px}
      .cf-auth-overlay[hidden]{display:none!important}
      .cf-auth-modal{width:min(470px,100%);max-height:min(760px,92vh);overflow:auto;background:#fff;border-radius:20px;box-shadow:0 24px 80px rgba(0,0,0,.24);padding:26px;position:relative}
      .cf-auth-close{position:absolute;right:14px;top:12px;border:0;background:transparent;font-size:28px;cursor:pointer;color:#526158}
      .cf-auth-kicker{text-transform:uppercase;letter-spacing:.08em;font-size:11px;font-weight:800;color:#6f7e75;margin-bottom:7px}
      .cf-auth-modal h2{margin:0 34px 8px 0;font-size:25px;color:#1d3327}.cf-auth-modal p{color:#66736c;line-height:1.5}
      .cf-auth-tabs{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:5px;background:#eef2ed;border-radius:12px;margin:18px 0}
      .cf-auth-tabs button{border:0;border-radius:9px;padding:10px;background:transparent;font-weight:750;cursor:pointer}.cf-auth-tabs button.active{background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.07)}
      .cf-auth-form{display:grid;gap:13px}.cf-auth-name-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:520px){.cf-auth-name-row{grid-template-columns:1fr}}.cf-auth-form[hidden]{display:none!important}.cf-auth-form label{display:grid;gap:6px;font-size:13px;font-weight:700;color:#46564d}
      .cf-auth-form input{width:100%;box-sizing:border-box;padding:12px 13px;border:1px solid #cdd6d0;border-radius:10px;font:inherit;background:#fff}
      .cf-auth-submit{border:0;border-radius:11px;padding:13px 16px;background:#1f6d35;color:#fff;font-weight:800;cursor:pointer}.cf-auth-submit:disabled{opacity:.55;cursor:wait}
      .cf-auth-link{border:0;background:transparent;color:#326944;text-decoration:underline;cursor:pointer;padding:0;font:inherit}.cf-auth-message{min-height:22px;font-size:13px;color:#8a3d32}.cf-auth-message.ok{color:#317347}
      .cf-account-card{background:#f2f5f1;border-radius:14px;padding:16px;margin:16px 0}.cf-account-plan{display:inline-flex;padding:4px 8px;border-radius:999px;background:#e3efe5;color:#1f6d35;font-size:11px;font-weight:850;letter-spacing:.06em}
      .cf-profile-section{margin:18px 0;padding-top:2px}.cf-profile-section h3{margin:0 0 10px;color:#1d3327;font-size:16px}
      .cf-profile-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.cf-profile-grid label,.cf-profile-email{display:grid;gap:6px;font-size:13px;font-weight:700;color:#46564d}
      .cf-profile-grid input,.cf-profile-email input{width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #cdd6d0;border-radius:10px;font:inherit;background:#fff}
      .cf-profile-email{margin-top:10px}.cf-profile-email input{background:#f4f6f4;color:#6e7972}
      .cf-profile-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.cf-profile-secondary{border:1px solid #ccd7d0;border-radius:10px;padding:10px 13px;background:#fff;color:#294737;font-weight:750;cursor:pointer}
      .cf-danger-zone{margin-top:20px;padding-top:16px;border-top:1px solid #ead8d6}.cf-danger-zone h3{margin:0 0 6px;color:#7a2d28;font-size:15px}.cf-danger-zone p{margin:5px 0 11px;font-size:12px}
      .cf-danger-button{border:1px solid #d9aaa6;border-radius:10px;padding:10px 13px;background:#fff6f5;color:#8d302a;font-weight:800;cursor:pointer}
      .cf-danger-confirm{margin-top:10px;padding:12px;border-radius:11px;background:#fff2f0}.cf-danger-confirm[hidden]{display:none!important}
      .cf-danger-confirm button{margin-top:8px}.cf-profile-message{min-height:20px;margin-top:8px;font-size:12px;color:#2f7044}.cf-profile-message.error{color:#8d302a}
      @media(max-width:520px){.cf-profile-grid{grid-template-columns:1fr}}
      .cf-plus-lock{border:1px solid #d8dfd9;background:#f8faf7;border-radius:14px;padding:16px;margin-top:18px}.cf-plus-lock strong{color:#1d3327}
      .cf-auth-toast{position:fixed;z-index:13000;left:50%;bottom:24px;transform:translateX(-50%);background:#203329;color:#fff;padding:10px 15px;border-radius:999px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.2)}
      [data-plus-feature][data-auth-state="locked"]{position:relative}[data-plus-feature][data-auth-state="locked"] small::before{content:'🔒 ';font-size:9px}
      .top-nav #auth-button.cf-auth-connected{border-color:#8fb69a;background:#f0f6f1;color:#245c35}
    `;
    document.head.appendChild(style);
  }

  function modalHtml(mode='login') {
    if (currentUser()) {
      const firstName = state.profile?.first_name || currentUser()?.user_metadata?.first_name || '';
      const lastName = state.profile?.last_name || currentUser()?.user_metadata?.last_name || '';
      return `<div class="cf-auth-kicker">Compte ClimaFlora</div>
        <h2>Mon profil</h2>
        <div class="cf-account-card"><div class="cf-account-plan">${esc(currentPlan())}</div>
        <p>${hasPlus() ? 'ClimaFlora+ est actif sur ce compte.' : 'Compte gratuit. Les fonctions Mes projets, Ma palette et Comparateur nécessitent ClimaFlora+.'}</p></div>

        <section class="cf-profile-section">
          <h3>Informations personnelles</h3>
          <form class="cf-auth-form" data-cf-profile-form>
            <div class="cf-profile-grid">
              <label>Prénom<input name="first_name" type="text" autocomplete="given-name" maxlength="80" required value="${esc(firstName)}"></label>
              <label>Nom<input name="last_name" type="text" autocomplete="family-name" maxlength="80" required value="${esc(lastName)}"></label>
            </div>
            <label class="cf-profile-email">Email<input type="email" value="${esc(currentUser().email || '')}" readonly aria-readonly="true"></label>
            <div class="cf-profile-message" data-cf-profile-message></div>
            <div class="cf-profile-actions">
              <button class="cf-auth-submit" type="submit">Enregistrer</button>
              <button class="cf-profile-secondary" data-cf-logout type="button">Se déconnecter</button>
            </div>
          </form>
        </section>

        <div data-cf-billing-slot></div>
        ${isAdmin() ? '<div data-cf-admin-slot></div>' : ''}
        ${!hasPlus() ? `<div class="cf-plus-lock"><strong>ClimaFlora+</strong><p>Mes projets, Ma palette et Comparateur seront disponibles avec ClimaFlora+.</p></div>` : ''}

        <section class="cf-danger-zone">
          <h3>Supprimer mon compte</h3>
          <p>Cette action supprime définitivement le compte ClimaFlora et ses données personnelles, projets, palettes et comparaisons.</p>
          <button class="cf-danger-button" data-cf-delete-start type="button">Supprimer mon compte</button>
          <div class="cf-danger-confirm" data-cf-delete-confirm hidden>
            <strong>Confirmer la suppression définitive ?</strong>
            <p>Cette action est irréversible.</p>
            <button class="cf-danger-button" data-cf-delete-confirm-button type="button">Oui, supprimer définitivement</button>
          </div>
        </section>`;
    }

    if (!state.configured) {
      return `<div class="cf-auth-kicker">Compte ClimaFlora</div><h2>Connexion</h2>
        <div class="cf-plus-lock"><strong>Infrastructure de comptes à activer</strong><p>Le frontend est prêt. Il faut renseigner l’URL Supabase et la clé publique dans <code>static/auth-config.js</code>.</p></div>`;
    }

    const loginActive = mode !== 'register';
    return `<div class="cf-auth-kicker">Compte ClimaFlora</div><h2>Votre espace personnel</h2><p>Sauvegardez vos projets et accédez aux fonctions ClimaFlora+.</p>
      <div class="cf-auth-tabs"><button type="button" data-cf-tab="login" class="${loginActive?'active':''}">Connexion</button><button type="button" data-cf-tab="register" class="${!loginActive?'active':''}">Créer un compte</button></div>
      <form class="cf-auth-form" data-cf-form="login" ${loginActive?'':'hidden'}>
        <label>Email<input name="email" type="email" autocomplete="email" required></label>
        <label>Mot de passe<input name="password" type="password" autocomplete="current-password" required minlength="8"></label>
        <div class="cf-auth-message" data-cf-message></div><button class="cf-auth-submit" type="submit">Se connecter</button>
        <p><button class="cf-auth-link" data-cf-recovery type="button">Mot de passe oublié ?</button></p>
      </form>
      <form class="cf-auth-form" data-cf-form="register" ${!loginActive?'':'hidden'}>
        <div class="cf-auth-name-row">
          <label>Prénom<input name="first_name" type="text" autocomplete="given-name" maxlength="80" required></label>
          <label>Nom<input name="last_name" type="text" autocomplete="family-name" maxlength="80" required></label>
        </div>
        <label>Email<input name="email" type="email" autocomplete="email" required></label>
        <label>Mot de passe<input name="password" type="password" autocomplete="new-password" required minlength="8"></label>
        <div class="cf-auth-message" data-cf-message></div><button class="cf-auth-submit" type="submit">Créer mon compte</button>
      </form>`;
  }

  function ensureModal() {
    if (state.modal?.isConnected) return state.modal;
    const overlay = document.createElement('div');
    overlay.className = 'cf-auth-overlay';
    overlay.hidden = true;
    overlay.innerHTML = `<section class="cf-auth-modal" role="dialog" aria-modal="true" aria-label="Connexion ClimaFlora"><button class="cf-auth-close" type="button" aria-label="Fermer">×</button><div data-cf-modal-body></div></section>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', event => { if (event.target === overlay) closeModal(); });
    overlay.querySelector('.cf-auth-close')?.addEventListener('click', closeModal);
    state.modal = overlay;
    return overlay;
  }

  function bindModal() {
    const overlay = ensureModal();
    const body = overlay.querySelector('[data-cf-modal-body]');
    body.querySelectorAll('[data-cf-tab]').forEach(button => button.addEventListener('click', () => renderModal(button.dataset.cfTab)));
    body.querySelectorAll('[data-cf-logout]').forEach(button => button.addEventListener('click', logout));

    const profileForm = body.querySelector('[data-cf-profile-form]');
    profileForm?.addEventListener('submit', async event => {
      event.preventDefault();
      const message = profileForm.querySelector('[data-cf-profile-message]');
      const submit = profileForm.querySelector('[type="submit"]');
      message.textContent = '';
      message.classList.remove('error');
      submit.disabled = true;
      try {
        const form = new FormData(profileForm);
        await updateOwnProfile(form.get('first_name'), form.get('last_name'));
        message.textContent = 'Profil enregistré.';
        setTimeout(() => renderModal('account'), 450);
      } catch (error) {
        message.classList.add('error');
        message.textContent = friendlyError(error);
      } finally {
        submit.disabled = false;
      }
    });

    body.querySelector('[data-cf-delete-start]')?.addEventListener('click', () => {
      const confirmBox = body.querySelector('[data-cf-delete-confirm]');
      if (confirmBox) confirmBox.hidden = false;
    });

    body.querySelector('[data-cf-delete-confirm-button]')?.addEventListener('click', async event => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        await deleteOwnAccount();
      } catch (error) {
        button.disabled = false;
        const box = body.querySelector('[data-cf-delete-confirm]');
        if (box) {
          const p = document.createElement('p');
          p.className = 'cf-auth-message';
          p.textContent = friendlyError(error);
          box.appendChild(p);
        }
      }
    });

    const loginForm = body.querySelector('[data-cf-form="login"]');
    loginForm?.addEventListener('submit', async event => {
      event.preventDefault();
      const message = loginForm.querySelector('[data-cf-message]');
      const submit = loginForm.querySelector('[type="submit"]');
      message.textContent=''; submit.disabled=true;
      try {
        const form = new FormData(loginForm);
        await login(form.get('email'), form.get('password'));
        closeModal();
        toast(`Connexion réussie · ${currentPlan()}`);
        if (state.pendingFeature) handlePlusFeature(state.pendingFeature);
      } catch (error) { message.textContent = friendlyError(error); }
      finally { submit.disabled=false; }
    });

    const registerForm = body.querySelector('[data-cf-form="register"]');
    registerForm?.addEventListener('submit', async event => {
      event.preventDefault();
      const message = registerForm.querySelector('[data-cf-message]');
      const submit = registerForm.querySelector('[type="submit"]');
      message.textContent=''; submit.disabled=true;
      try {
        const form = new FormData(registerForm);
        const result = await register(form.get('first_name'), form.get('last_name'), form.get('email'), form.get('password'));
        if (result.session) { closeModal(); toast('Compte créé et connexion réussie.'); }
        else { message.classList.add('ok'); message.textContent='Compte créé. Vérifiez votre email pour confirmer votre adresse.'; }
      } catch (error) { message.textContent = friendlyError(error); }
      finally { submit.disabled=false; }
    });

    body.querySelector('[data-cf-recovery]')?.addEventListener('click', async () => {
      const email = loginForm?.querySelector('[name="email"]')?.value?.trim();
      const message = loginForm?.querySelector('[data-cf-message]');
      if (!email) { if (message) message.textContent='Saisissez votre email ci-dessus.'; return; }
      try { await sendRecovery(email); if (message) { message.classList.add('ok'); message.textContent='Email de récupération envoyé si ce compte existe.'; } }
      catch (error) { if (message) message.textContent=friendlyError(error); }
    });
  }

  function renderModal(mode='login') {
    const overlay = ensureModal();
    overlay.querySelector('[data-cf-modal-body]').innerHTML = modalHtml(mode);
    bindModal();
  }

  function openModal(mode='login') {
    renderModal(mode);
    const overlay = ensureModal();
    overlay.hidden = false;
    document.body.style.overflow='hidden';
  }

  function closeModal() {
    if (state.modal) state.modal.hidden = true;
    document.body.style.overflow='';
  }

  function friendlyError(error) {
    const text = String(error?.message || 'Erreur de connexion.');
    if (/invalid login credentials/i.test(text)) return 'Email ou mot de passe incorrect.';
    if (/user already registered/i.test(text)) return 'Un compte existe déjà avec cet email.';
    if (/password/i.test(text) && /least/i.test(text)) return 'Le mot de passe est trop court.';
    return text;
  }

  function toast(message) {
    document.querySelector('.cf-auth-toast')?.remove();
    const node = document.createElement('div');
    node.className='cf-auth-toast'; node.textContent=message;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 2800);
  }

  function handlePlusFeature(feature) {
    state.pendingFeature = feature;
    if (!currentUser()) {
      openModal('login');
      return false;
    }
    if (!hasPlus()) {
      openModal('account');
      return false;
    }
    state.pendingFeature = null;
    window.dispatchEvent(new CustomEvent('climaflora:plus-feature', {detail:{feature, user:currentUser(), profile:state.profile}}));
    toast(`Accès ${feature} autorisé · ${currentPlan()}`);
    return true;
  }

  function bindPage() {
    document.getElementById('auth-button')?.addEventListener('click', () => openModal(currentUser() ? 'account' : 'login'));
    document.getElementById('plus-discover')?.addEventListener('click', () => openModal(currentUser() ? 'account' : 'register'));
    document.querySelectorAll('[data-plus-feature]').forEach(button => {
      button.disabled = false;
      button.addEventListener('click', () => handlePlusFeature(button.dataset.plusFeature));
    });
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
  }

  async function init() {
    injectStyles();
    bindPage();
    syncUi();
    if (!state.configured) return;
    state.session = loadStoredSession();
    if (!state.session) return syncUi();
    try {
      await verifySession();
      await loadProfile();
    } catch (error) {
      console.warn(`ClimaFlora auth v${VERSION}: session restore failed`, error);
    }
    syncUi();
  }

  window.CLIMAFLORA_AUTH = Object.freeze({
    version: VERSION,
    get configured(){ return state.configured; },
    get authenticated(){ return Boolean(currentUser()); },
    get user(){ return currentUser(); },
    get profile(){ return state.profile; },
    get plan(){ return currentPlan(); },
    get role(){ return currentRole(); },
    get isAdmin(){ return isAdmin(); },
    get accessToken(){ return state.session?.access_token || ''; },
    can(feature){ return ['projects','palette','comparator'].includes(String(feature)) ? hasPlus() : false; },
    open: openModal,
    logout,
    reloadProfile: async () => { await loadProfile(); syncUi(); return state.profile; },
    updateProfile: updateOwnProfile,
    deleteAccount: deleteOwnAccount,
    requirePlus: handlePlusFeature
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
