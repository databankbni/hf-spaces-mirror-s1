(() => {
  'use strict';

  const VERSION = '1.0.0';
  const cfg = window.CLIMAFLORA_BILLING_CONFIG || {};
  const authCfg = window.CLIMAFLORA_AUTH_CONFIG || {};

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));

  function auth() { return window.CLIMAFLORA_AUTH; }
  function base() { return String(cfg.functionsBase || '').replace(/\/$/, ''); }

  function headers() {
    const token = auth()?.accessToken || '';
    return {
      'apikey': String(authCfg.publicKey || ''),
      'Authorization': token ? `Bearer ${token}` : '',
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  async function invoke(name, body={}) {
    if (!base()) throw new Error('Fonctions de paiement non configurées.');
    if (!auth()?.authenticated || !auth()?.accessToken) throw new Error('Connexion requise.');
    const response = await fetch(`${base()}/${name}`, {
      method:'POST',
      cache:'no-store',
      headers:headers(),
      body:JSON.stringify(body)
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload?.error || payload?.message || `HTTP ${response.status}`);
    return payload;
  }

  async function rpc(name, body={}) {
    if (!auth()?.authenticated || !auth()?.accessToken) throw new Error('Connexion requise.');
    const supabaseUrl = String(authCfg.supabaseUrl || '').replace(/\/$/, '');
    if (!supabaseUrl) throw new Error('Supabase non configuré.');

    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/${name}`, {
      method:'POST',
      cache:'no-store',
      headers:{
        'apikey': String(authCfg.publicKey || ''),
        'Authorization': `Bearer ${auth().accessToken}`,
        'Content-Type':'application/json',
        'Accept':'application/json'
      },
      body:JSON.stringify(body)
    });

    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const message = payload?.message || payload?.hint || payload?.details || `HTTP ${response.status}`;
      throw new Error(message);
    }
    return payload;
  }

  function injectStyles() {
    if (document.getElementById('cf-billing-admin-styles')) return;
    const style = document.createElement('style');
    style.id = 'cf-billing-admin-styles';
    style.textContent = `
      .cf-billing-card,.cf-admin-card{margin:14px 0;padding:15px;border:1px solid #dce5df;border-radius:14px;background:#f8faf8}
      .cf-billing-card h3,.cf-admin-card h3{margin:0 0 7px;color:#1d3327;font-size:16px}
      .cf-billing-card p,.cf-admin-card p{margin:6px 0;color:#617067;font-size:13px;line-height:1.45}
      .cf-billing-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
      .cf-billing-actions button,.cf-admin-card button{border:0;border-radius:10px;padding:10px 12px;cursor:pointer;font-weight:750}
      .cf-billing-primary{background:#1d6b3c;color:white}.cf-billing-secondary{background:#e7eee9;color:#234531}
      .cf-admin-button{width:100%;margin-top:8px;background:#1d3327;color:#fff}
      .cf-admin-overlay{position:fixed;inset:0;z-index:13000;background:rgba(14,27,20,.56);display:grid;place-items:center;padding:18px}
      .cf-admin-overlay[hidden]{display:none!important}
      .cf-admin-panel{width:min(1050px,100%);max-height:92vh;overflow:auto;background:#fff;border-radius:18px;padding:22px;box-shadow:0 24px 90px rgba(0,0,0,.28)}
      .cf-admin-head{display:flex;align-items:center;justify-content:space-between;gap:16px}
      .cf-admin-head button{border:0;background:transparent;font-size:26px;cursor:pointer}
      .cf-admin-table{width:100%;border-collapse:collapse;margin-top:16px;font-size:13px}
      .cf-admin-table th,.cf-admin-table td{padding:9px 8px;border-bottom:1px solid #e8eeea;text-align:left;vertical-align:middle}
      .cf-admin-table select{padding:6px 8px;border:1px solid #ced9d2;border-radius:8px;background:#fff}
      .cf-admin-status{font-size:12px;color:#6d7c73}
      .cf-admin-error{padding:10px;border-radius:10px;background:#fff0ef;color:#8a2a25;margin-top:10px}
      @media(max-width:680px){.cf-billing-actions{grid-template-columns:1fr}.cf-admin-table{min-width:760px}.cf-admin-panel{overflow:auto}}
    `;
    document.head.appendChild(style);
  }

  async function startCheckout(interval) {
    const button = document.querySelector(`[data-cf-checkout="${interval}"]`);
    if (button) button.disabled = true;
    try {
      const payload = await invoke('create-checkout-session', {interval});
      if (!payload?.url) throw new Error('URL Stripe Checkout absente.');
      window.location.assign(payload.url);
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function openPortal() {
    const payload = await invoke('create-portal-session');
    if (!payload?.url) throw new Error('URL du portail Stripe absente.');
    window.location.assign(payload.url);
  }

  function billingHtml() {
    const a = auth();
    const profile = a?.profile || {};
    const plus = ['PLUS','PRO'].includes(String(a?.plan || 'FREE').toUpperCase());
    const billingStatus = String(profile.billing_status || '').toLowerCase();
    const stripeActive = ['active','trialing','past_due'].includes(billingStatus);

    if (plus || stripeActive) {
      const end = profile.current_period_end ? new Date(profile.current_period_end).toLocaleDateString('fr-FR') : '';
      return `<div class="cf-billing-card">
        <h3>Abonnement ClimaFlora+</h3>
        <p>Statut : <strong>${esc(billingStatus || 'actif')}</strong>${end ? ` · période jusqu’au ${esc(end)}` : ''}${profile.cancel_at_period_end ? ' · résiliation programmée' : ''}</p>
        <div class="cf-billing-actions"><button class="cf-billing-secondary" data-cf-portal type="button">Gérer mon abonnement</button></div>
      </div>`;
    }

    return `<div class="cf-billing-card">
      <h3>Passer à ClimaFlora+</h3>
      <p>Débloquez Mes projets, Ma palette et le Comparateur. Le paiement est traité par Stripe.</p>
      <div class="cf-billing-actions">
        <button class="cf-billing-primary" data-cf-checkout="month" type="button">Abonnement mensuel</button>
        <button class="cf-billing-secondary" data-cf-checkout="year" type="button">Abonnement annuel</button>
      </div>
    </div>`;
  }

  function adminSlotHtml() {
    return `<div class="cf-admin-card"><h3>Administration</h3><p>Gestion des comptes, droits et abonnements ClimaFlora.</p><button class="cf-admin-button" data-cf-open-admin type="button">Ouvrir l’administration</button></div>`;
  }

  function decorateAccountModal() {
    const billingSlot = document.querySelector('[data-cf-billing-slot]');
    if (billingSlot && !billingSlot.dataset.ready) {
      billingSlot.dataset.ready = '1';
      billingSlot.innerHTML = billingHtml();
      billingSlot.querySelectorAll('[data-cf-checkout]').forEach(button => {
        button.addEventListener('click', async () => {
          try { await startCheckout(button.dataset.cfCheckout); }
          catch (e) { alert(`Paiement indisponible : ${e.message}`); }
        });
      });
      billingSlot.querySelector('[data-cf-portal]')?.addEventListener('click', async () => {
        try { await openPortal(); } catch (e) { alert(`Portail indisponible : ${e.message}`); }
      });
    }

    const adminSlot = document.querySelector('[data-cf-admin-slot]');
    if (adminSlot && auth()?.isAdmin && !adminSlot.dataset.ready) {
      adminSlot.dataset.ready = '1';
      adminSlot.innerHTML = adminSlotHtml();
      adminSlot.querySelector('[data-cf-open-admin]')?.addEventListener('click', openAdmin);
    }
  }

  async function adminUsers() {
    const rows = await rpc('climaflora_admin_users', {});
    return {users:Array.isArray(rows) ? rows : []};
  }

  async function adminSetPlan(userId, plan) {
    await rpc('climaflora_admin_set_plan', {
      p_user_id:userId,
      p_plan:plan
    });
    return {ok:true, user_id:userId, plan};
  }

  async function loadAdmin(panel) {
    const body = panel.querySelector('[data-cf-admin-body]');
    body.innerHTML = '<p>Chargement des utilisateurs…</p>';
    try {
      const payload = await adminUsers();
      const users = Array.isArray(payload?.users) ? payload.users : [];
      body.innerHTML = users.length ? `
        <div class="cf-admin-status">${users.length} compte${users.length>1?'s':''}</div>
        <div style="overflow:auto">
        <table class="cf-admin-table">
          <thead><tr><th>Utilisateur</th><th>Email</th><th>Plan</th><th>Paiement</th><th>Créé</th></tr></thead>
          <tbody>${users.map(u => `<tr>
            <td>${esc([u.first_name,u.last_name].filter(Boolean).join(' ') || '—')}${u.role==='ADMIN'?' <strong>ADMIN</strong>':''}</td>
            <td>${esc(u.email || '')}</td>
            <td><select data-cf-user-plan="${esc(u.id)}">
              ${['FREE','PLUS','PRO'].map(p => `<option value="${p}" ${u.plan===p?'selected':''}>${p}</option>`).join('')}
            </select></td>
            <td>${esc(u.billing_status || '—')}</td>
            <td>${u.created_at ? esc(new Date(u.created_at).toLocaleDateString('fr-FR')) : '—'}</td>
          </tr>`).join('')}</tbody>
        </table></div>` : '<p>Aucun compte utilisateur.</p>';

      body.querySelectorAll('[data-cf-user-plan]').forEach(select => {
        select.addEventListener('change', async () => {
          const previous = select.dataset.previous || '';
          select.disabled = true;
          try {
            await adminSetPlan(select.dataset.cfUserPlan, select.value);
            select.dataset.previous = select.value;
          } catch (e) {
            if (previous) select.value = previous;
            alert(`Modification refusée : ${e.message}`);
          } finally {
            select.disabled = false;
          }
        });
        select.dataset.previous = select.value;
      });
    } catch (e) {
      body.innerHTML = `<div class="cf-admin-error">${esc(e.message)}</div>`;
    }
  }

  function openAdmin() {
    if (!auth()?.isAdmin) return;
    let overlay = document.querySelector('.cf-admin-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'cf-admin-overlay';
      overlay.innerHTML = `<section class="cf-admin-panel" role="dialog" aria-modal="true" aria-label="Administration ClimaFlora">
        <div class="cf-admin-head"><div><div class="cf-auth-kicker">ClimaFlora</div><h2>Administration</h2></div><button data-cf-close-admin aria-label="Fermer">×</button></div>
        <div data-cf-admin-body></div>
      </section>`;
      document.body.appendChild(overlay);
      overlay.querySelector('[data-cf-close-admin]').addEventListener('click', () => overlay.hidden = true);
      overlay.addEventListener('click', e => { if (e.target === overlay) overlay.hidden = true; });
    }
    overlay.hidden = false;
    loadAdmin(overlay);
  }

  function installObserver() {
    const observer = new MutationObserver(decorateAccountModal);
    observer.observe(document.body, {childList:true, subtree:true});
    decorateAccountModal();
  }

  async function reconcileReturn() {
    const url = new URL(window.location.href);
    const billing = url.searchParams.get('billing');
    if (!billing) return;
    url.searchParams.delete('billing');
    history.replaceState({}, '', url.pathname + (url.search ? `?${url.searchParams}` : '') + url.hash);
    if (billing === 'success' && auth()?.authenticated) {
      setTimeout(async () => {
        try {
          await auth().reloadProfile();
          decorateAccountModal();
        } catch {}
      }, 1200);
    }
  }

  function init() {
    injectStyles();
    installObserver();
    window.addEventListener('climaflora:auth-changed', () => setTimeout(decorateAccountModal, 0));
    setTimeout(reconcileReturn, 300);
  }

  window.CLIMAFLORA_BILLING = Object.freeze({
    version: VERSION,
    checkout: startCheckout,
    portal: openPortal,
    openAdmin
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
