(() => {
  'use strict';

  const cache = new Map();
  const waiting = new Map();
  let flushTimer = null;
  let fetching = false;

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));

  function apiBase() {
    return String(
      window.CLIMAFLORA_RUNTIME?.apiBase ||
      window.CLIMAFLORA_CONFIG?.apiBase ||
      'https://gyamotab-climaflora-engine.hf.space/api/v1'
    ).replace(/\/$/, '');
  }

  function taxonId(card) {
    return String(card?.querySelector('[data-taxon]')?.dataset.taxon || '').trim();
  }

  function scientificName(card) {
    return card?.querySelector('.plant-name em')?.textContent?.trim()
      || card?.querySelector('.plant-name')?.textContent?.trim()
      || '';
  }

  function validImage(data) {
    const image = data?.image;
    if (!image?.thumbnail_url || !image?.source_page_url) return null;
    if (image.source_name !== 'wikimedia_commons') return null;
    if (image.display_blurred) return null;
    try {
      const thumb = new URL(image.thumbnail_url);
      const source = new URL(image.source_page_url);
      if (thumb.protocol !== 'https:' || thumb.hostname !== 'upload.wikimedia.org') return null;
      if (source.protocol !== 'https:' || source.hostname !== 'commons.wikimedia.org') return null;
    } catch (_) { return null; }
    return image;
  }

  function creditText(image) {
    return [image?.author, image?.license, 'Wikimedia Commons'].filter(Boolean).join(' · ');
  }

  function ensureDialog() {
    if (document.getElementById('cf-media-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'cf-media-overlay';
    overlay.className = 'cf-media-overlay';
    overlay.hidden = true;
    overlay.innerHTML = `
      <div class="cf-media-dialog" role="dialog" aria-modal="true" aria-labelledby="cf-media-title">
        <button class="cf-media-close" type="button" aria-label="Fermer">×</button>
        <div id="cf-media-dialog-content"></div>
      </div>`;
    document.body.appendChild(overlay);
    const close = () => {
      overlay.hidden = true;
      document.body.classList.remove('cf-media-open');
    };
    overlay.addEventListener('click', event => { if (event.target === overlay) close(); });
    overlay.querySelector('.cf-media-close')?.addEventListener('click', close);
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !overlay.hidden) close();
    });
  }

  function openDialog(card, image) {
    ensureDialog();
    const overlay = document.getElementById('cf-media-overlay');
    const content = document.getElementById('cf-media-dialog-content');
    if (!overlay || !content) return;
    const name = scientificName(card);
    const credit = creditText(image);
    content.innerHTML = `
      <div class="cf-media-dialog-image">
        <img src="${esc(image.image_url || image.thumbnail_url)}" alt="Illustration de ${esc(name)}" decoding="async" referrerpolicy="no-referrer">
      </div>
      <div class="cf-media-dialog-body">
        <div class="cf-media-kicker">Illustration botanique</div>
        <h3 id="cf-media-title"><em>${esc(name)}</em></h3>
        <p class="cf-media-credit-full">Photo : ${esc(credit || 'Wikimedia Commons')}</p>
        <a href="${esc(image.source_page_url)}" target="_blank" rel="noopener noreferrer">Voir la source et la licence sur Wikimedia Commons ↗</a>
        <p class="cf-media-note">Image illustrative uniquement. Elle n’intervient ni dans l’identification botanique ni dans le score ClimaFlora.</p>
      </div>`;
    content.querySelector('img')?.addEventListener('error', event => {
      event.currentTarget.closest('.cf-media-dialog-image')?.classList.add('image-error');
      event.currentTarget.remove();
    }, {once:true});
    overlay.hidden = false;
    document.body.classList.add('cf-media-open');
  }

  function decorate(card, data) {
    if (!card || card.dataset.cfMediaDone === '1') return;
    const image = validImage(data);
    if (!image) {
      card.dataset.cfMediaDone = '1';
      card.dataset.cfMedia = 'none';
      return;
    }
    const thumb = card.querySelector('.plant-thumb');
    if (!thumb) return;

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'plant-thumb cf-media-thumb';
    button.setAttribute('aria-label', `Ouvrir la photo de ${scientificName(card)}`);
    button.title = creditText(image) || 'Wikimedia Commons';
    button.innerHTML = `
      <img src="${esc(image.thumbnail_url)}" alt="Illustration de ${esc(scientificName(card))}" loading="lazy" decoding="async" referrerpolicy="no-referrer">
      <span class="cf-media-credit-badge">${esc([image.author, image.license].filter(Boolean).join(' · ') || image.license || 'Wikimedia')}</span>`;
    button.addEventListener('click', () => openDialog(card, image));
    button.querySelector('img')?.addEventListener('error', () => {
      button.replaceWith(thumb);
      card.dataset.cfMedia = 'broken';
    }, {once:true});
    thumb.replaceWith(button);
    card.dataset.cfMediaDone = '1';
    card.dataset.cfMedia = 'wikimedia';
  }

  async function fetchBatch(ids) {
    const params = new URLSearchParams();
    ids.forEach(id => params.append('taxon_id', id));
    const response = await fetch(`${apiBase()}/plants/enrichment?${params}`, {
      cache: 'no-store', credentials: 'omit', headers: {'Accept':'application/json'}
    });
    if (!response.ok) throw new Error(`enrichment ${response.status}`);
    const payload = await response.json();
    const taxa = payload?.taxa || {};
    ids.forEach(id => cache.set(id, taxa[id] || null));
  }

  async function flush() {
    flushTimer = null;
    if (fetching || !waiting.size) return;
    fetching = true;
    try {
      const entries = [...waiting.entries()].slice(0, 60);
      entries.forEach(([id]) => waiting.delete(id));
      const missing = entries.map(([id]) => id).filter(id => !cache.has(id));
      if (missing.length) await fetchBatch(missing);
      entries.forEach(([id, cards]) => cards.forEach(card => decorate(card, cache.get(id))));
    } catch (error) {
      console.warn('ClimaFlora media unavailable:', error);
    } finally {
      fetching = false;
      if (waiting.size) scheduleFlush();
    }
  }

  function scheduleFlush() {
    if (flushTimer) return;
    flushTimer = setTimeout(flush, 70);
  }

  function queue(card) {
    if (!card || card.dataset.cfMediaQueued === '1' || card.dataset.cfMediaDone === '1') return;
    const id = taxonId(card);
    if (!id) return;
    card.dataset.cfMediaQueued = '1';
    const cards = waiting.get(id) || [];
    cards.push(card);
    waiting.set(id, cards);
    scheduleFlush();
  }

  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      queue(entry.target);
    });
  }, {rootMargin:'700px 0px'}) : null;

  function observeCards(root=document) {
    const cards = [...root.querySelectorAll?.('.plant-card') || []];
    cards.forEach(card => {
      if (card.dataset.cfMediaObserved === '1') return;
      card.dataset.cfMediaObserved = '1';
      if (observer) observer.observe(card); else queue(card);
    });
  }

  function init() {
    ensureDialog();
    const list = document.getElementById('results-list');
    if (!list) return;
    observeCards(list);
    new MutationObserver(() => observeCards(list)).observe(list, {childList:true,subtree:true});
    document.addEventListener('toggle', event => {
      if (event.target?.classList?.contains('genus-group') && event.target.open) observeCards(event.target);
    }, true);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
