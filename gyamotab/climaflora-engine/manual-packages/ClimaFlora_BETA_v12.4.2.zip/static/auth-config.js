(() => {
  'use strict';

  // Public browser configuration only. Never put a Supabase service_role key here.
  // These values are intentionally public in a browser application.
  window.CLIMAFLORA_AUTH_CONFIG = Object.freeze({
    provider: 'supabase',
    supabaseUrl: 'https://haclvcuxadvuigtefeqz.supabase.co',
    publicKey: 'sb_publishable_nmZ0ruh9PieRqbP3oJll6g_fDZzaIYe',
    redirectUrl: ['shugoan.com','www.shugoan.com'].includes(window.location.hostname)
      ? 'https://shugoan.com/climaflora/'
      : `${window.location.origin}${window.location.pathname}`
  });
})();
