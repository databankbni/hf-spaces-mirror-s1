(() => {
  'use strict';
  const config = window.CLIMAFLORA_CONFIG || {};
  if (!config.supabaseUrl || !config.supabasePublishableKey || !window.supabase?.createClient) return;

  const client = window.supabase.createClient(config.supabaseUrl, config.supabasePublishableKey, {
    auth: {persistSession: true, autoRefreshToken: true, detectSessionInUrl: true}
  });
  const state = {session: null, profile: null};

  const shell = document.createElement('div');
  shell.innerHTML = `<div class="auth-backdrop" data-auth-close hidden></div>
    <section class="auth-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-title" hidden>
      <button class="auth-close" data-auth-close aria-label="Fermer" type="button">×</button>
      <div data-auth-guest>
        <p class="auth-kicker">Compte ClimaFlora</p><h2 id="auth-title">Se connecter</h2>
        <p class="auth-copy">Retrouvez vos projets et choisissez une offre avec la même adresse e-mail.</p>
        <form data-auth-form>
          <label>Adresse e-mail<input name="email" type="email" autocomplete="email" required></label>
          <label>Mot de passe<input name="password" type="password" autocomplete="current-password" minlength="8" required></label>
          <div class="auth-actions"><button class="auth-primary" name="action" value="signin">Connexion</button><button name="action" value="signup">Créer mon compte</button></div>
        </form>
        <div class="auth-sostagora"><span>Déjà client Sostagora&nbsp;?</span><a class="auth-primary" data-sostagora-login href="#">Activer ClimaFlora Plus</a></div>
      </div>
      <div data-auth-user hidden>
        <p class="auth-kicker">Mon compte</p><h2>Bonjour</h2><p data-auth-email></p>
        <div class="auth-plan"><span>Offre actuelle</span><strong data-auth-plan>Découverte</strong></div>
        <div class="auth-actions"><a class="auth-primary" href="tarifs.html">Voir les offres</a><button data-auth-portal type="button" hidden>Gérer l’abonnement</button><button data-auth-signout type="button">Déconnexion</button></div>
      </div>
      <p class="auth-status" data-auth-status role="status" aria-live="polite" hidden></p>
    </section>`;
  document.body.append(...shell.children);

  const dialog = document.querySelector('.auth-dialog');
  const backdrop = document.querySelector('.auth-backdrop');
  const guest = dialog.querySelector('[data-auth-guest]');
  const userPanel = dialog.querySelector('[data-auth-user]');
  const status = dialog.querySelector('[data-auth-status]');
  const apiBase = () => (window.CLIMAFLORA_RUNTIME?.apiBase || config.apiBase || '').replace(/\/$/, '');
  dialog.querySelector('[data-sostagora-login]').href = config.sostagoraLoginUrl || 'https://shugoan.com/';

  function showStatus(text, isError = false) {
    status.textContent = text; status.hidden = !text; status.classList.toggle('error', isError);
  }
  function open() { dialog.hidden = false; backdrop.hidden = false; document.body.classList.add('auth-open'); dialog.querySelector('input')?.focus(); }
  function close() { dialog.hidden = true; backdrop.hidden = true; document.body.classList.remove('auth-open'); showStatus(''); }
  async function loadBilling() {
    state.profile = null;
    if (!state.session?.access_token) return render();
    try {
      const response = await fetch(`${apiBase()}/billing/me`, {headers: {Authorization: `Bearer ${state.session.access_token}`}});
      if (response.ok) state.profile = await response.json();
    } catch (_) { /* The account remains usable while billing is disabled. */ }
    render();
  }
  function render() {
    const signedIn = Boolean(state.session?.user);
    guest.hidden = signedIn; userPanel.hidden = !signedIn;
    document.querySelectorAll('[data-auth-open]').forEach(button => {
      button.disabled = false;
      button.textContent = signedIn ? 'Mon compte' : 'Connexion';
    });
    if (!signedIn) return;
    userPanel.querySelector('[data-auth-email]').textContent = state.session.user.email || '';
    userPanel.querySelector('[data-auth-plan]').textContent = {PLUS:'Plus', PRO:'Pro'}[state.profile?.plan] || 'Découverte';
    userPanel.querySelector('[data-auth-portal]').hidden = state.profile?.subscription_management !== 'stripe';
  }
  async function billingPost(path) {
    const response = await fetch(`${apiBase()}/billing/${path}`, {method:'POST', headers:{Authorization:`Bearer ${state.session.access_token}`}});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || 'Service momentanément indisponible.');
    return payload;
  }
  async function handleSostagoraLogin() {
    const url = new URL(location.href);
    const code = url.searchParams.get('sostagora_code');
    const result = url.searchParams.get('sostagora');
    if (code) {
      url.searchParams.delete('sostagora_code');
      history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
      open(); showStatus('Activation de votre accès Sostagora…');
      try {
        const response = await fetch(`${apiBase()}/auth/sostagora/exchange`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({code})
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok || !payload.url) throw new Error(payload.detail || 'Connexion Sostagora impossible.');
        location.assign(payload.url);
      } catch (error) {
        showStatus(error.message, true);
      }
      return;
    }
    if (result === 'success') {
      url.searchParams.delete('sostagora');
      history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
      open(); showStatus('Votre accès ClimaFlora Plus est activé.');
    } else if (result === 'forbidden') {
      url.searchParams.delete('sostagora');
      history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
      open(); showStatus('Aucun accès client Sostagora actif n’a été trouvé.', true);
    }
  }

  document.addEventListener('click', event => { if (event.target.closest('[data-auth-open]')) open(); });
  document.querySelectorAll('[data-auth-close]').forEach(node => node.addEventListener('click', close));
  dialog.querySelector('[data-auth-signout]').addEventListener('click', async () => { await client.auth.signOut(); close(); });
  dialog.querySelector('[data-auth-portal]').addEventListener('click', async () => {
    showStatus('Ouverture du portail sécurisé…');
    try { location.assign((await billingPost('portal')).url); } catch (error) { showStatus(error.message, true); }
  });
  dialog.querySelector('[data-auth-form]').addEventListener('submit', async event => {
    event.preventDefault();
    const submitter = event.submitter?.value || 'signin';
    const data = new FormData(event.currentTarget);
    const credentials = {email: String(data.get('email')).trim(), password: String(data.get('password'))};
    showStatus(submitter === 'signup' ? 'Création du compte…' : 'Connexion…');
    const result = submitter === 'signup' ? await client.auth.signUp(credentials) : await client.auth.signInWithPassword(credentials);
    if (result.error) return showStatus(result.error.message, true);
    if (submitter === 'signup' && !result.data.session) showStatus('Compte créé. Consultez votre e-mail pour confirmer votre adresse.');
    else { showStatus('Connexion réussie.'); await loadBilling(); }
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !dialog.hidden) close(); });

  window.CLIMAFLORA_AUTH = {
    client,
    get accessToken() { return state.session?.access_token || ''; },
    get session() { return state.session; },
    open
  };
  client.auth.onAuthStateChange((_event, session) => {
    state.session = session;
    setTimeout(loadBilling, 0);
  });
  client.auth.getSession().then(({data}) => { state.session = data.session; loadBilling(); });
  handleSostagoraLogin();
})();
