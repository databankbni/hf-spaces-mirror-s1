(() => {
  'use strict';
  const STORAGE_KEY = 'climaflora_consent_v1';
  const CONSENT_VERSION = '2026-08-24';
  const VALIDITY_MS = 183 * 24 * 60 * 60 * 1000;
  const GOOGLE_ID = 'G-57WVVQMH0C';
  const META_ID = '1467038648472822';
  let active = {analytics:false, marketing:false};
  let analyticsLoaded = false;
  let marketingLoaded = false;

  function readChoice() {
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!value || value.version !== CONSENT_VERSION || Date.now() - value.savedAt > VALIDITY_MS) return null;
      return {analytics:Boolean(value.analytics), marketing:Boolean(value.marketing)};
    } catch (_) { return null; }
  }
  function saveChoice(choice) {
    active = {analytics:Boolean(choice.analytics), marketing:Boolean(choice.marketing)};
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({...active, version:CONSENT_VERSION, savedAt:Date.now()})); }
    catch (_) { /* Le choix s’applique à la page même si le stockage est bloqué. */ }
    applyChoice();
    closeUi();
  }
  function expireCookie(name) {
    const hosts = ['', ';domain=.shugoan.com', ';domain=shugoan.com'];
    hosts.forEach(domain => { document.cookie = `${name}=;path=/${domain};expires=Thu, 01 Jan 1970 00:00:00 GMT;SameSite=Lax;Secure`; });
  }
  function clearCookies(pattern) {
    document.cookie.split(';').map(v => v.split('=')[0].trim()).filter(name => pattern.test(name)).forEach(expireCookie);
  }
  function loadAnalytics() {
    if (analyticsLoaded) {
      window.gtag?.('consent', 'update', {analytics_storage:'granted'});
      return;
    }
    analyticsLoaded = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function(){ window.dataLayer.push(arguments); };
    window.gtag('consent', 'default', {analytics_storage:'denied', ad_storage:'denied', ad_user_data:'denied', ad_personalization:'denied'});
    window.gtag('js', new Date());
    window.gtag('config', GOOGLE_ID, {anonymize_ip:true, cookie_expires:33696000, cookie_flags:'SameSite=Lax;Secure'});
    window.gtag('consent', 'update', {analytics_storage:'granted'});
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(GOOGLE_ID)}`;
    document.head.appendChild(script);
  }
  function loadMarketing() {
    if (marketingLoaded) { window.fbq?.('consent', 'grant'); return; }
    marketingLoaded = true;
    const f = window.fbq = window.fbq || function(){ f.callMethod ? f.callMethod.apply(f, arguments) : f.queue.push(arguments); };
    if (!window._fbq) window._fbq = f;
    f.push = f; f.loaded = true; f.version = '2.0'; f.queue = [];
    f('consent', 'grant'); f('init', META_ID); f('track', 'PageView');
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://connect.facebook.net/fr_FR/fbevents.js';
    document.head.appendChild(script);
  }
  function applyChoice() {
    if (active.analytics) loadAnalytics();
    else { window.gtag?.('consent', 'update', {analytics_storage:'denied'}); clearCookies(/^_ga/); }
    if (active.marketing) loadMarketing();
    else { window.fbq?.('consent', 'revoke'); clearCookies(/^_(fbp|fbc)$/); }
  }
  function ui() {
    let root = document.getElementById('climaflora-consent');
    if (root) return root;
    root = document.createElement('div');
    root.id = 'climaflora-consent';
    root.innerHTML = `<section class="consent-banner" role="dialog" aria-modal="false" aria-labelledby="consent-title" hidden>
      <h2 id="consent-title">Vos choix de confidentialité</h2>
      <p>ClimaFlora utilise un stockage nécessaire au compte. Avec votre accord, Google Analytics mesure l’audience et Meta Pixel mesure les campagnes. Vous pouvez accepter, refuser ou choisir par finalité. <a href="cookies.html">En savoir plus</a>.</p>
      <div class="consent-actions"><button data-consent="refuse">Tout refuser</button><button data-consent="customize">Personnaliser</button><button class="primary" data-consent="accept">Tout accepter</button></div>
    </section>
    <div class="consent-backdrop" hidden></div>
    <section class="consent-modal" role="dialog" aria-modal="true" aria-labelledby="consent-settings-title" hidden>
      <button class="consent-close" type="button" aria-label="Fermer" data-consent="close">×</button>
      <h2 id="consent-settings-title">Gérer mes cookies</h2><p>Les cookies nécessaires restent actifs. Les autres catégories sont facultatives et peuvent être modifiées à tout moment.</p>
      <div class="consent-option"><span><strong>Nécessaires</strong><small>Session Supabase, sécurité et mémorisation de vos choix.</small></span><input type="checkbox" checked disabled aria-label="Cookies nécessaires toujours actifs"></div>
      <label class="consent-option"><span><strong>Mesure d’audience</strong><small>Google Analytics, pour comprendre l’utilisation de ClimaFlora.</small></span><input type="checkbox" data-consent-analytics></label>
      <label class="consent-option"><span><strong>Publicité et conversion</strong><small>Meta Pixel, pour mesurer l’efficacité des campagnes.</small></span><input type="checkbox" data-consent-marketing></label>
      <div class="consent-actions"><button data-consent="refuse">Tout refuser</button><button class="primary" data-consent="save">Enregistrer mes choix</button></div>
    </section>`;
    document.body.appendChild(root);
    root.addEventListener('click', event => {
      const action = event.target.closest('[data-consent]')?.dataset.consent;
      if (action === 'accept') saveChoice({analytics:true, marketing:true});
      if (action === 'refuse') saveChoice({analytics:false, marketing:false});
      if (action === 'customize') openSettings();
      if (action === 'save') saveChoice({analytics:root.querySelector('[data-consent-analytics]').checked, marketing:root.querySelector('[data-consent-marketing]').checked});
      if (action === 'close') closeUi();
    });
    root.querySelector('.consent-backdrop').addEventListener('click', closeUi);
    return root;
  }
  function closeUi() {
    const root = document.getElementById('climaflora-consent');
    if (!root) return;
    root.querySelectorAll('.consent-banner,.consent-modal,.consent-backdrop').forEach(node => node.hidden = true);
    document.body.classList.remove('consent-open');
  }
  function openSettings() {
    const root = ui();
    root.querySelector('.consent-banner').hidden = true;
    root.querySelector('[data-consent-analytics]').checked = active.analytics;
    root.querySelector('[data-consent-marketing]').checked = active.marketing;
    root.querySelector('.consent-backdrop').hidden = false;
    root.querySelector('.consent-modal').hidden = false;
    document.body.classList.add('consent-open');
    root.querySelector('.consent-close').focus();
  }
  function init() {
    const choice = readChoice();
    if (choice) { active = choice; applyChoice(); }
    else ui().querySelector('.consent-banner').hidden = false;
    document.addEventListener('click', event => { if (event.target.closest('[data-consent-manage]')) { event.preventDefault(); openSettings(); } });
    window.CLIMAFLORA_CONSENT = {open:openSettings, get choice(){return {...active};}};
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true}); else init();
})();
