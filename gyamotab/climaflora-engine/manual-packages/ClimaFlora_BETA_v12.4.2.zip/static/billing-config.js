(() => {
  'use strict';

  const authCfg = window.CLIMAFLORA_AUTH_CONFIG || {};
  const supabaseUrl = String(authCfg.supabaseUrl || '').replace(/\/$/, '');

  window.CLIMAFLORA_BILLING_CONFIG = Object.freeze({
    version: '1.0.0',
    functionsBase: supabaseUrl ? `${supabaseUrl}/functions/v1` : '',
    currencyLabel: 'EUR',
    // Actual Stripe Price IDs remain server-side Supabase secrets.
    plusIntervals: ['month', 'year']
  });
})();
