(() => {
  'use strict';
  const form = document.getElementById('withdrawal-form');
  if (!form) return;
  const value = name => String(new FormData(form).get(name) || '').trim();
  function letter() {
    return `À l’attention de SHUGO-AN — Guilhem Bato\n1, le Grand Moulin Bondu, 44330 Vallet, France\ncontact@shugoan.com\n\nJe vous notifie par la présente ma rétractation du contrat portant sur l’abonnement ClimaFlora suivant : ${value('offer')}.\n\nCommande souscrite le : ${value('ordered_at')}\nAdresse e-mail du compte : ${value('email')}\nNom du consommateur : ${value('name')}\nAdresse du consommateur : ${value('address')}\n\nDate : ${new Date().toLocaleDateString('fr-FR')}\n\nSignature (uniquement en cas d’envoi papier) :`;
  }
  document.getElementById('withdrawal-email').addEventListener('click', () => {
    if (!form.reportValidity()) return;
    location.href = `mailto:contact@shugoan.com?subject=${encodeURIComponent('Rétractation abonnement ClimaFlora')}&body=${encodeURIComponent(letter())}`;
  });
  document.getElementById('withdrawal-copy').addEventListener('click', async () => {
    if (!form.reportValidity()) return;
    await navigator.clipboard.writeText(letter());
    const status = document.getElementById('withdrawal-status');
    status.textContent = 'Le formulaire a été copié dans le presse-papiers.';
    status.hidden = false;
  });
  document.getElementById('withdrawal-print').addEventListener('click', () => { if (form.reportValidity()) window.print(); });
})();
